<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

	<head>

		<header>
			<?php echo $__env->yieldContent('header'); ?>
		</header>



		<content>
			<?php echo $__env->yieldContent('conten'); ?>
		</content>


		<footer>
			<?php echo $__env->yieldContent('footer'); ?>
		</footer>

	</head>

</body>
</html>
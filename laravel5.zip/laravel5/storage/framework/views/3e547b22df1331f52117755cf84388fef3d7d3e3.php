<?php $__env->startSection('title', 'Ini adalaha halaman utama'); ?>

<?php $__env->startSection('header'); ?>
    <h1>Belum ada</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Belum ada</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <h1>Belum ada</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
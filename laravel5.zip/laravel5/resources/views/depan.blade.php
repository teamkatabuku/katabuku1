@extends ('layouts.master')

@section('title', 'Ini adalaha halaman utama')

@section('header')
    <h1>Belum ada</h1>

@endsection

@section('content')
    <h1>Belum ada</h1>

@endsection

@section('footer')
    <h1>Belum ada</h1>

@endsection
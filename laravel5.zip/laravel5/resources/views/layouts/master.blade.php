<!DOCTYPE html>
<html>
<head>
	<title>@yield('title')</title>
</head>
<body>

	<head>

		<header>
			@yield('header')
		</header>



		<content>
			@yield('conten')
		</content>


		<footer>
			@yield('footer')
		</footer>

	</head>

</body>
</html>